#pragma once
#include <pthread.h>

typedef struct Reactor
{

int fd;

pthread_t chat_thread;

void* (*func)(void*);

} Reactor, *P_reactor ;

typedef struct requests
{
    int fd;

    P_reactor my_P_reactor;

} requests, *P_requests;





